Simba Academy Frontend — cPanel

1. File Manager → public_html
2. Upload & extract simba-frontend.zip here
3. Ensure .htaccess is present for client-side routing
4. API must be live at the URL baked into this build

Full guide: DEPLOY-CPANEL.md in the repo (or simba-api.zip)